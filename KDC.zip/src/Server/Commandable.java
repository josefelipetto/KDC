package Server;

public interface Commandable {

    void handle();
}
