package Clients;

public interface Commandable {
    void handle();
}
